/* nodejs demó és teszt progri: a "csány_példa5_ajax" java servlet átirata */

const express = require('express');
const format = require('string-format');                          /* jó a 'Seldonos példa!: https://www.npmjs.com/package/string-format */
const session = require('express-session');
const bodyParser=require('body-parser');
const app    = express();
const port   = 3000;
var DB       = require('./datamodule_mysql.js');
const { strict } = require('assert');
const ujsor  = "<div class='ujsor'></div>\n";

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.static('public'));    /* kliens oldal: public mappa app.use(express.urlencoded()); app.use(express.json()); */
app.use(session({                     /* https://www.js-tutorials.com/nodejs-tutorial/nodejs-session-example-using-express-session */
   key:'user_sid', secret:'nagyontitkos', resave:true, saveUninitialized:true }));





app.post('/kategoria',   (req, res) => {  /* ----------kategória listadoboz ----------------------- */
    res.set('Content-Type', 'text/html; charset=UTF-8');
    const keret = "<option value='{0}'>{1}</option>";
    var content = format(keret, "0", "--- minden ---") ;
    var sql = "SELECT ID_KATEGORIA, KATEGORIA FROM alapanyag_kategoriak ORDER BY KATEGORIA";
    DB.query(sql, null, function (json_data, error) {    
      if (!error) {
        var data = JSON.parse(json_data);
        for (i=0; i<data.dataset.length; ++i) {
          content += format(keret, data.dataset[i].ID_KATEGORIA, data.dataset[i].KATEGORIA ) ;
        } 
      } else { console.log(error); }
      res.end(content);
    });
  });
app.get('/getUser',(req,res)=>{
    session_data = req.session;
        res.set('Content-Type', 'application/json; charset=UTF-8')
       let user= "login: "+session_data.NEV+ "<br>["+Funkcio(session_data.FUNKCIO)+"]"
        res.send(session_data.NEV?{USER:user,LINK:`2_${Funkcio(session_data.FUNKCIO).toLowerCase().replace("á","a").replace("é","e")}.html`}:{USER:"login: még senki...",LINK:"login.html"})
        res.end()
})

app.post('/users',(req,res)=>{
    res.set('Content-Type', 'text/html; charset=UTF-8')
      session_data = req.session;
      if (session_data.NEV) {
          const fejlec  = [ "Név", "Cím", "Telefonszám", "Email cím","Funkció","Törlés","Modositás"];
          const mezok=["NEV","CIM","TELEFON","EMAIL","FUNKCIO"]
          const hossz   = [ 140, 200, 150, 170,100,100,100]; 
          const keret = "<div class='t{0}' style='width:{1}px;'>{2}</div>";
          var content="<div class='button uj'onclick='getAddUser()'> Insert</div> <div id='tabla'> "+ujsor  
          for ( let i = 0; i < fejlec.length; ++i)  { 
                  content += format(keret, "f", hossz[i], fejlec[i]); 
          }
          content += ujsor
          let sql=`SELECT ID_USER, NEV,CIM,TELEFON,EMAIL,
                   case
                       when FUNKCIO=0 then "Vendég"
                       when FUNKCIO=1 then "Szakács"
                       when FUNKCIO=2 then "Futár"
                       ELSE  "Boss"
                   END as FUNKCIO
                   FROM userek;`
            DB.query(sql,null,function(sting_data,error){
              var data = JSON.parse(sting_data);
              var result=data.dataset
              for(var i=0;i<result.length;i++){
                  for ( let j = 0; j < mezok.length; j++)  { 
                      content += format(keret, i%2, hossz[j], result[i][mezok[j]]); 
				  }
				  content+=`<div class='t${i%2}' style='width:${hossz[5]}px;' onclick="${session_data.ID_USER!=result[i].ID_USER?"deleteUser("+result[i].ID_USER+")":"$('#n1').mySend({text:'Magadat nem törölheted', tip:'error', mp:0})"}">Töröl</div>`
				  content+=`<div class='t${i%2}' style='width:${hossz[5]}px;' onclick="updateUser(${result[i].ID_USER})">Modosiiit</div>`
                  content += ujsor
  
              }
              res.end(content+"</div>");
          })
      }else
      res.end("Be kell jeletkezned hogy ezt láthsd :(>")
  
})
app.post('/delUser',(req,res)=>{
    res.set('Content-Type', 'application/json; charset=UTF-8')
    session_data = req.session;
    if (session_data.NEV) {
        let id=req.query.id|0
        if(session_data.ID_USER!=id){
            let sql="DELETE FROM userek WHERE  ID_USER="+id+";"
            DB.query(sql,null,function(json_data,err){
                let data=JSON.parse(json_data)
                res.end(data.message)
            })
        }
        else{console.log(session_data.NEV+": saját magát akarta törölni")}
    }
})
app.route('/upUser')
.get((req,res)=>{
    session_data = req.session;
    res.set('Content-Type', 'text/html; charset=UTF-8');
    if (session_data.NEV) {
        let id=req.query.id|0
        let sql="SELECT ID_USER, NEV, CIM, TELEFON,EMAIL, PASSWORD,FUNKCIO FROM userek WHERE  ID_USER="+id+";"
        DB.query(sql,null ,(json_data,err)=>{
            if (err) 
                res.end(err)
            else{
                let data=JSON.parse(json_data)
                res.end(Form(data.dataset[0]))
            }
        })
    }
    else{ res.end()}
})
.post((req,res)=>{	
    res.set('Content-Type', 'text/html; charset=UTF-8')
    session_data = req.session;
    if (session_data.NEV) {
        let id=req.query.id|0
        let data=req.body
        let sql="UPDATE userek SET "
        let t=[]
        Object.keys(data).forEach(k=>{
            if(k=="PASSWORD" && data[k])
                t.push(`${k}=md5("${data[k]}")`)
            else
                t.push(`${k}="${data[k]}"`)
        })
        sql+=t.join(", ")
        sql+=" WHERE ID_USER="+id
        DB.query(sql,null ,(json_data,err)=>{
            if(!err){
            res.end(json_data)
        }
        else res.end(err)

        })
    }
})
app.route('/addUser')
.get((req,res)=>{
    res.set('Content-Type', 'text/html; charset=UTF-8');
    session_data = req.session;
    if (session_data.NEV) {
        const labels=[ "Név", "Cím", "Telefonszám", "Email cím","Jelszó","Funkció"]
        const mezok=["NEV","CIM","TELEFON","EMAIL","PASSWORD","FUNKCIO"]
        let form="<h3>Új felhasználo rögzitése</h3><form id='newUserData' style='float: left;'>"
        mezok.forEach((x,i)=>{
            form+=`<label >${labels[i]}</label>
            <input type="text" name="${x}" id="${x}">`+ (i%2? ujsor:'')
        })
        form+="<div class='button ment' onclick='postAddUser()' style='bottom: 10px;'>Felvétel</div></form>"
        res.end(form)

    }
    else res.end('Be kell jelentkezned')
})
.post((req,res)=>{
    res.set('Content-Type', 'text/html; charset=UTF-8')
    session_data = req.session;
    if (session_data.NEV) {
        let data= req.body;
        let sql="insert into userek values (null,"
        let t=[]
        Object.keys(data).forEach(k=>{
            if(k=="PASSWORD")
                t.push(`md5("${data[k]}")`)
            else
                t.push(`"${data[k]}"`)
        })
        sql+=t.join(", ")+");"
        DB.query(sql,data,function(json_data,err){
            if (!err){
            res.end(json_data)
            }
            else res.end(err)
        })
    }
    else res.end('Be kell jelentkezned')

})
app.get('/kajak',  (req, res) => {  /* ---------- xm2.html ----- ez itt egy 'antitézis példa a restful-ra :-) */
    var card_keret="<div class='kajásdoboz' id='D{0}'>"+
    "    <img src='images/{1}'>"+
    "    <div class='top'>  "+
    "    <div class='név'>{2}</div>"+
    "    <div class='cont'>({3})</div>"+
    "    </div>"+
    "    <div class='btm'>"+
    "       <div class='ár'>{4},-Ft</div>"+ 
    "       <label>Mennyiség:</label>"+
    "       <input style='width:80px;' id='DB_{0}' name='MENNYISEG' type='number' value='1'>"+
    "    </div>"+
    "    <div class='kosárba' onclick='add_kosar({0})' id='B{0}'>kosárba</div>"+
    "</div>"
    var content=""
    let sql="SELECT ID_ETEL, NEV, FOTO, AR, LEIRAS FROM etelek WHERE ETLAPON = 'Y' AND KESZLET>0 "
    DB.query(sql,null,function(json_data,err){
        if(!err){
            var data = JSON.parse(json_data)
            data.dataset.forEach((x)=>{ content+= format(card_keret,x.ID_ETEL,x.FOTO,x.NEV,x.LEIRAS,x.AR) })
            res.set('Content-Type', 'text/html; charset=UTF-8')
            res.send(content)
            res.end()         
            }
    })
});

app.post('/logout0',   (req, res) => {  /* ---------- xm0.html ----------------------- */
    session_data = req.session;
    session_data.destroy( function(err)
    { res.json("Sikeres Kijelentkezés");
      res.end();}
    );

});

app.get("/kosar",(req,res)=>{
    session_data=req.session
    if(session_data.ID_USER){
        sql=`SELECT ID_TETEL, MENNYISEG, NEV, LEIRAS
             FROM rendelesek r INNER JOIN rendelesek_tetelei rt ON r.ID_RENDELES=rt.ID_RENDELES
                 INNER JOIN etelek e ON rt.ID_ETEL =e.ID_ETEL 
             WHERE USER_LEZART='N' AND UZEM_LEZART='N' AND USER_FIZET='N' AND  r.ID_RENDELES=${session_data.ID_RENDELES} 
             ORDER BY DATUMIDO;`
        DB.query(sql,null,(data,error)=>{
            res.set('Content-Type', 'application/json; charset=UTF-8');
            res.end(data?data:error)
        })
    }
    else res.end("jelentkezz be");

})
app.post("/kosar/add",(req,res)=>{
    res.set('Content-Type', 'application/json; charset=UTF-8');
    session_data=req.session
    if(session_data.ID_USER){
            if(session_data.ID_RENDELES){
            var body=req.body
            let sql=`INSERT INTO rendelesek_tetelei (ID_RENDELES,ID_ETEL,MENNYISEG) VALUES ('${session_data.ID_RENDELES}','${body.ID_ETEL}','${body.MENNYISEG}') `
            DB.query(sql,null,(json_data,error)=>{
                res.end(json_data?json_data:error);
            })                 
        }
        else res.end(JSON.stringify({text:"Már lezártad rendelést", tip:"error"}));

    }
    else res.end("jelentkezz be");

})
app.delete("/kosar/remove",(req,res)=>{
    res.set('Content-Type', 'application/json; charset=UTF-8');
    session_data=req.session
    if(session_data.ID_USER){
        if(session_data.ID_RENDELES){
            var ID_TETEL=req.query.ID_TETEL 
            let sql=`DELETE FROM rendelesek_tetelei WHERE ID_TETEL=${ID_TETEL} LIMIT 1;`
            DB.query(sql,null,(json_data,error)=>{
                res.end(json_data?json_data:error);
            })
        }
        else res.end(JSON.stringify({text:"Már lezártad rendelést", tip:"error"}));
    }
    else res.end("jelentkezz be");

})
app.get("/kosar/lezar",(req,res)=>{
    res.set('Content-Type', 'application/json; charset=UTF-8');
    session_data=req.session
    if(session_data.ID_USER){
        if(session_data.ID_RENDELES){
            let sql=`  UPDATE rendelesek SET USER_LEZART='Y' WHERE ID_RENDELES=${session_data.ID_RENDELES}`
            DB.query(sql,null,(json_data,error)=>{
                session_data.ID_RENDELES=null
                res.end(json_data?json_data:error);
            })     
        }                  
        else res.end(JSON.stringify({text:"Már lezártad rendelést", tip:"error"}));
    }
    else res.end("jelentkezz be");
})
app.get('/profit',(req,res)=>{
    session_data=req.session
    if(session_data.FUNKCIO==3){
        let beg=req.query.beg
        let end=req.query.end

        if(!beg||!end) {
            res.set('Content-Type', 'application/json; charset=UTF-8');
            res.send({text:"Ha a profitra vagy kiváncsi akkor mondmeg mikor", tip:"alert"});
            res.end()
        }
        else{
            let sql=`   SELECT  Concat(SUM(MENNYISEG*AR)+""," Ft") AS Bevétel,COUNT(*) AS Darab,  NEV AS Termék
                        FROM rendelesek r INNER JOIN rendelesek_tetelei rt ON r.ID_RENDELES=rt.ID_RENDELES
                            INNER JOIN etelek e ON rt.ID_ETEL =e.ID_ETEL 
                        WHERE USER_LEZART='Y' AND UZEM_LEZART='Y' AND USER_FIZET='Y'
                        AND DATE_FORMAT(DATUMIDO,'%Y-%m-%d')>'${beg}' AND DATE_FORMAT(DATUMIDO,'%Y-%m-%d')<'${end}'
                        GROUP BY NEV;`
            Send_to_JSON(req,res,sql)
        }
    }
    else{
        res.set('Content-Type', 'application/json; charset=UTF-8');
        res.send({text:"Ehez nincs jogod", tip:"error"});
        res.end()
    }
})
app.get('/szakacs',(req,res)=>{
    if(session_data.FUNKCIO==1){
    let sql=`SELECT r.ID_RENDELES, SZALL
    ITAS, USER_LEZART, UZEM_LEZART, USER_FIZET, GROUP_CONCAT(concat(NEV,'(',MENNYISEG,'db) :',LEIRAS) SEPARATOR '<br>') AS Tetelek 
            FROM rendelesek r INNER JOIN rendelesek_tetelei rt ON r.ID_RENDELES=rt.ID_RENDELES
            INNER JOIN etelek e ON rt.ID_ETEL =e.ID_ETEL 
            WHERE USER_LEZART='Y' AND UZEM_LEZART='N' AND USER_FIZET='N'
            group by r.ID_RENDELES

            ORDER BY DATUMIDO;`
    Send_to_JSON(req,res,sql);ű
}
else{
    res.set('Content-Type', 'application/json; charset=UTF-8');
    res.send({text:"Ehez nincs jogod", tip:"error"});
    res.end()
}
})
app.get('/futar',(req,res)=>{
    if(session_data.FUNKCIO==2){
    let sql=`SELECT r.ID_RENELES,u.NEV,u.CIM,u.TELEFON, SZALLITAS, USER_LEZART, UZEM_LEZART, USER_FIZET, FIZMOD
    FROM rendelesek r INNER JOIN userek u ON r.ID_USER=u.ID_USER
    WHERE USER_LEZART='Y' AND UZEM_LEZART='Y' AND USER_FIZET='N'
   ORDER BY DATUMIDO`
    Send_to_JSON(req,res,sql);
}
    else{
        res.set('Content-Type', 'application/json; charset=UTF-8');
        res.send({text:"Ehez nincs jogod", tip:"error"});
        res.end()
    }
})
app.post('/szakacs/lezar',(req,res)=>{
    if(session_data.FUNKCIO==1){
    let id=req.body.ID_RENDELES?req.body.ID_RENDELES:0
    console.log(req.body)
    let sql=`UPDATE rendelesek SET UZEM_LEZART='Y' WHERE ID_RENDELES=${id} AND USER_LEZART='Y'`
    Send_to_JSON(req,res,sql)
}
else{
    res.set('Content-Type', 'application/json; charset=UTF-8');
    res.send({text:"Ehez nincs jogod", tip:"error"});
    res.end()
}

})
app.post('/futar/lezar',(req,res)=>{
    if(session_data.FUNKCIO==2){
    let id=req.body.ID_RENDELES?req.body.ID_RENDELES:0
    let sql=`UPDATE rendelesek SET USER_FIZET='Y' WHERE ID_RENDELES=${id} AND USER_LEZART='Y' AND UZEM_LEZART='Y'`
    Send_to_JSON(req,res,sql)}
    else{
        res.set('Content-Type', 'application/json; charset=UTF-8');
        res.send({text:"Ehez nincs jogod", tip:"error"});
        res.end()
    }
})


app.post('/login0',    (req, res) => {  /* ---------- xm0.html ----------------------- */ 
  var user= (req.query.USER? req.query.USER: "");
  var psw = (req.query.PSW? req.query.PSW  : "");
  var sql = format("select ID_USER, NEV, FUNKCIO from userek where EMAIL='{0}' and PASSWORD=md5('{1}') limit 1;", user, psw);
  console.log(sql)
  DB.query(sql, null, function (json_data, error) {    
      var data = error ? error : JSON.parse(json_data);
          if (data.count == 1)  {       /* sikeres bejelentkezés, megvan a juzer... */
              session_data = req.session;
              session_data.ID_USER = data.dataset[0].ID_USER;
              session_data.NEV     = data.dataset[0].NEV;
              session_data.FUNKCIO=data.dataset[0].FUNKCIO
              session_data.MOST    = Date.now();
              data.dataset[0].FUNKCIO=Funkcio(data.dataset[0].FUNKCIO)
              if (session_data.FUNKCIO==0)
                DB.query(`INSERT INTO rendelesek (ID_USER) VALUES (${session_data.ID_USER}) `,null, function(json_data,error){
                    if(json_data)
                    DB.query("SELECT @id AS ID_RENDELES limit 1;",null,function(json,err){
                        session_data.ID_RENDELES=JSON.parse(json).dataset[0].ID_RENDELES
                        res.set('Content-Type', 'application/json; charset=UTF-8');
                        res.send(data);
                        res.end();
                    })
                })
                else{
                    res.set('Content-Type', 'application/json; charset=UTF-8');
                    res.send(data);
                    res.end();
              
                }
             }
      
  });
});

function Funkcio(num){
    switch (num) {
        case 0:
            return "Vendég"
        case 1:
            return "Szakács"
        case 2:
            return "Futár"
          default:
            return "Boss"
      }
}

app.listen(port, function () { console.log(`Example app listening at http://localhost:${port}`); });


function Form(json) {
        let keys=Object.keys(json)
        let form=''
        form+="<form id='input'>"
        keys.forEach((k)=>{
            if (k!="ID_USER"){
                form+=`<label >${k}</label></br>`
                form+=`<input type="${k=="PASSWORD"?'password':'text'}" name="${k}" value='${json[k]}'><div class='ujsor'></div>`
            }
        })
        form+=`</br><div onclick="sendUpdate(${json['ID_USER']})">UPDATE</div>`
        form+=`</form>`
    return form
    }

    function Send_to_JSON (req, res, sql) {
        console.log("\r\n"+sql+"\r\n")
            DB.query( sql, null, function (json_data, error) {
                var data = error ? error : json_data;
                res.set('Content-Type', 'application/json; charset=UTF-8');
                res.send(JSON.parse(data));
                res.end();  
            }); 
    }

