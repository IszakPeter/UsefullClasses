
var Common = {
    ajax_get: function ( urlsor, hova, tipus, aszinkron ) {
        $.ajax({url: urlsor, type:"get", async:aszinkron, cache:false, dataType:tipus===0?'html':'json',
            beforeSend:function(xhr)   { $('#loader1').css("display","block"); }, 
            success:   function(data)  { $(hova).html(data); },
            error:     function(jqXHR, textStatus, errorThrown) {$('#n1').mySend({text:jqXHR.responseText, tip:"error", mp:0});},
            complete:  function()      { $('#loader1').css("display","none"); }   
        });
    return true;
    }, 

    ajax_post: function ( urlsor, tipus  ) {
        var s = "";
        $.ajax({url: urlsor, type:"post", async:false, cache:false, dataType:tipus===0?'html':'json',
            beforeSend:function(xhr)   { $('#loader1').css("display","block"); }, 
            success:   function(data)  { s = data; },
            error:     function(jqXHR, textStatus, errorThrown) {$('#n1').mySend({text:jqXHR.responseText, tip:"error", mp:0});},
            complete:  function()      { $('#loader1').css("display","none"); } 
        });
    return s;
    }  
};

   /*-------------------- mySend function ------------------------------------*/ 
                                              
(function($){
    $.fn.mySend = function(ops) {                                           // üzenet ;info(def), alert, question, error; max. megjelenítési idő mp(0=nincs időzítés)
        var defOps = {text:"", tip:"info", mp:5,                            /*tip: info, alert, error, question; mp: 5 másodperc (0:off) */
            ok:    function() { _close(); },                                /* override ! ok gomb */
            no:    function() { _close(); },                                /* override ! no gomb */
            close: function() { _close(); }                                 
        } ;                                                                 // defs.
        ops = $.extend({}, defOps, ops);                                                // tömb összefésülése  
        var delay;
        var id  = $(this).attr("id");
        var idx = "#"+id;        
        var count =  $(idx+" > .keret").length;                             // ? db e.keret elem van az idx div-ben? 
        var item = id+"_"+(count+1); 
        var isq = (ops.tip.toLowerCase()==="question");                     // a question spec elem lesz
        var gombok = "";
        var time=new Date().toLocaleTimeString('hu-HU', { hour12: false,  year:'numeric', month:'numeric', day:'numeric', hour: "numeric",  minute: "numeric"});

        if (isq) gombok = "<div id='"+id+"_ok' class='button ok'><u>I</u>gen</div>"+
                          "<div id='"+id+"_no' class='button no'><u>N</u>em</div>";
        var s = "<div id='"+item+"' class='keret'>"+
                "<small>"+time+"</small>"+
                "<div class='close' id='"+item+"_close'></div>"+
                "<div>"+ops.text+"</div><div>"+gombok+"</div></div>";        

        $(idx).append(s); 
        $("#"+item).addClass(ops.tip); 
        if (isq) $(idx).wrap("<div class='BGmyModalWin' id='"+id+"_BG'></div>");     // Background parent létrehozása
        $("#"+item+"_close").click(function() { _close(); });
        if (ops.mp>0 && !isq) {delay=setTimeout(function(){ $("#"+item).fadeOut( 2000, function() {_close(); }); }, ops.mp*1000);}
        if (isq) {
            $(idx+"_ok").click(function(){ ops.ok(); }); 
            $(idx+"_no").click(function(){ ops.no(); }); 
            $(document).on ('keydown', function (e) {                       /* nagybetűsen adja vissza */
                    var c = String.fromCharCode(e.which);
                    if (c==="I") ops.ok();
                    if (c==="N") ops.no();
            }); 
        }

        function _close() {                                                 
           clearTimeout(delay);                             
           if (isq) $(idx).unwrap(idx+"_BG");                               // modal background törlése
           $("#"+item).remove(); 
        };
};
})(jQuery); 


(function($){                                 /* --- modális windows popup --- */
   $.fn.myModalWin = function(ops) {
    var defOps = { w:700, h:400, top:100, fej:"", cím:"", láb:"", cont:"", 
                   okButton:"", noButton:"", style:"myModalWin", 
                   okGombSytle:"ment" , escClose:true,
                   ok_something: function() { _close(); return 1; },
                   no_something: function() { _close(); return 0; },
                   close:        function() { _close(); return 0; }
                 } ;                                                        // defs.
    ops = $.extend({}, defOps, ops);                                        // tömb összefésülése
    var left= (($(window).width() / 2) - (ops.w / 2)) | 0;                  // így egész lesz :-)  
    $(this).css('left',left+'px');
    $(this).css('top' ,ops.top +'px');  
    $(this).css('width',ops.w+'px');
    $(this).css('height',ops.h+'px');
    var id = "#"+$(this).attr("id");                                        // pl: #myModalWin_1 
    var modalid = $(this).attr("id") + "_BG";                               // pl: #myModalWin_1_BG
    var closeid = $(this).attr("id") + "_Close";                            // pl: myModalWin_1_Close        
    var conteid = $(this).attr("id") + "_content";                        
    var noGombId= $(this).attr("id") + "_nogomb";
    var okGombId= $(this).attr("id") + "_okgomb";
    var sendId  = $(this).attr("id") + "_send";
    var gombStyle = "style='float: right;'";

    $(id).wrap("<div class='BGmyModalWin' id='"+modalid+"'></div>");        // Background parent létrehozása
    $(id).prepend("<div id='"+conteid+"'></div>");                          // content létrehozása
    $(id).prepend("<div class='close' id='"+closeid+"'></div>");            // close gomb létrehozása

     var _button = ((ops.noButton==="")? "" : "<div class='button megse' " + gombStyle + " id='"+noGombId+"'>"+ops.noButton+"</div>")+
                   ((ops.okButton==="")? "" : "<div class='button "+ops.okGombSytle+"' "+ gombStyle+" id='"+okGombId+"'>"+ops.okButton+"</div>");   

     var s = ((ops.fej==="")? "":"<h1>"+ops.fej+"</h1>")+
             ((ops.cím==="")? "":"<h2>"+ops.cím+"</h2>")+("<p>"+ops.cont+"</p>")+
             ((ops.láb==="" && _button==="")? "":"<h3><span id='"+sendId+"'>"+ops.láb+'</span>'+_button+"</h3>");    

     $('#'+conteid).html(s); 
     $(id).attr('class', ops.style);         
     $(id).css("display","block");                                          // show

     var _close = function() {                                              // private
        $('#'+closeid).remove();                                            // close törlése
        $('#'+conteid).remove();                                            // content törlése
        $(id).css("display","none");
        $(id).unwrap("#" + modalid);                                        // Background parent törlése (inner marad!)
     };

     if (ops.okButton!=="") { $('#'+okGombId).click(function(){ ops.ok_something(); });}
     if (ops.noButton!=="") { $('#'+noGombId).click(function(){ ops.no_something(); });}  // csak ha van noButton...
     if (ops.escClose===true) {$(document).keydown(function(e)  { if (e.keyCode==27) _close(); });} 
     $('#'+closeid).click(function()  { _close(); });  
  };

  $.fn.close = function() {                                                 // myModalWin bezárása
        var id = "#"+$(this).attr("id");   
        $(id+ "_Close").remove();                                           // close törlése
        $(id+ "_content").remove();                                         // content törlése
        $(id).css("display","none");
        $(id).unwrap(id+"_BG");                                             // Background parent törlése (inner marad!) 
  };

  $.fn.send = function(param) {                                             // myModalWin lábléc üzenet
        var id = "#"+$(this).attr("id");   
        $(id+"_send").html(param); 
  };

})(jQuery);       /* https://learn.jquery.com/plugins/basic-plugin-creation/ */

