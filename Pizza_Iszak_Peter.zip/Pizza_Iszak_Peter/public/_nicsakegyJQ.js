
(function($) {                                                              
    $.fn.myJsonTábla = function(ops) {
    var defOps = { dataSource:[], columns:[], sum:[], counter:false, buttons:[], /*"ins","del","upd","inf","src","end","home","load"*/
                    maxVisibleRow: 16, fontSize: 12, táblaCursor: true, tCursor: -1,
                    ins_something: function()      { return 0; },            /* override !  új rekord */
                    del_something: function()      { return 1; },            /* override !  del rekord */
                    upd_something: function()      { return 2; },            /* override !  upd rekord */
                    inf_something: function()      { return 3; },            /* override !  inf rekord */
                    load_something: function()     { return 4; },            /* override !  refresh (server) */
                    getCursor:     function()      { return _tCursor();   }, /* lista N. eleme */
                    setCursor:     function(a,b)   { _setCursor(a,b);  },    /* call: this.setCursor(37,1) a:cursor(0..MAX), b:1:scrollTo; */
                    getReccount:   function()      { return reccount; },     /*  elemszám */
                    getRowID:      function(i)     { return _getRowField(i,"ID"); },    /* jsonban keresi i. elem ID értékét (ha van ID)*/
                    getRowField:   function(i,x)   { return _getRowField(i,x); },       /* jsonban keresi i. x. fields elem értékét */
                    delRow:        function()      { _delRow( _tCursor()); },   /* külső híváskor az akt. rekordot törli */
                    addNewData:    function(data)  { _addNewData(data); },   /* tábla init */
                    setRow:        function(i,f,v) { _jsonSetRow(i, f, v);}  // json[i][field]=value+ refresh_setrow(i)
        } ;                                                                  // defs.
    ops = $.extend({}, defOps, ops);                                         // tömb összefésülése
    // ops.dataSource = JSON.parse(ops.dataSource);                          // majd ha paraméterből jön? !!! ellenőrizni kell az adattípust!
    
    var defColumns = {title:"", width:0, align:"L", pref:"", suff:"", type:"s"};
    for (var i=0; i < ops.columns.length; i++) {
        ops.columns[i] = $.extend({}, defColumns, ops.columns[i]);          // tömb összefésülése
    }
    
    // a rendezés előtt kell beszúrni a columns-ba a cid:0 checkbox oszlopot
    ops.columns.sort(function (a, b) { return a.cid - b.cid; });            // sort by cid - https://developer.mozilla.org/hu/docs/Web/JavaScript/Reference/Global_Objects/Array/sort
    
    var id  = $(this).attr("id");  
    var idx = "#"+id;  
    var reccount = ops.dataSource.length;                                   /* elemszám */
    var tábla  = "";
    var sumtb = Array(ops.sum.length).fill(0);                              /* kért oszlopok összesítésének tömbje*/
    var cid = -1;                                                           // oszlop azonosító
    var realColumns = 0;                                                    // tényleges oszlopszám (azonos CID értékek)
    var orderBy = 0;                                                        // 0: no order 2, -2 : 2. oszlop order, desc
    
    /* ------------ fejléc, thead ----------------------------------------*/    
    var header = "";
    for (var i=0; i < ops.columns.length; i++) {
        if (ops.columns[i].cid !== cid) {                                   // nem egyenlő az előzővel: új <th>
            ++realColumns;
            cid = ops.columns[i].cid;                                       // frissít
            header +="<th "+(id+"_th_"+i)+" style='width:"+ops.columns[i].width+"px;'>"+ops.columns[i].title+"<div class='order'></div></th>";    
        }
    }
    
    /*  ------------ lábléc, tfoot ---------------------------------------*/
    var sinput = "<input id='"+id+"_search' type='text'/>";
    var számláló =ops.counter?"[<span id='"+id+"_recno'>0</span> / <span id='"+id+"_reccount'>"+reccount+"</span>] |":"";
    var gombsor = "";
    var titles = {"ins":"Új rekord","del":"Akt. rekord törlése","upd":"Akt.rekord módosítása","inf":"infó","src":"keresés rendezett oszlopra...(on/off)","end":"utolsó rekord","home":"első rekord","load":"frissít"};
    for (var i = 0; i < ops.buttons.length; i++) { 
        gombsor += "<div title='"+titles[ops.buttons[i]]+"' id='"+id+"_"+ops.buttons[i]+"' class='tbutton "+ops.buttons[i]+"'></div>";  }
    var footer = "<tr><td><div id='"+id+"_láb' style='float:left; padding-top:6px;'>"+számláló+
                    "&nbsp;<span id='"+id+"_szum'></span></div><div style='float:left;'>"+gombsor+"</div>"+sinput+"</td></tr>";                 
        
    /*------------------------- tábla összeszerelése ---------------------*/
    tábla = "<table><thead><tr>"+header+"</tr></thead>"+
            "<tbody id='"+id+"_tbody'></tbody><tfoot>"+footer+"</tfoot></table>";
    $(idx+ " table").remove();                                              /* előző content törlése (ha volt) */
    $(idx).append(tábla);                                                   /* DOM generálása */
    for (var i=0; i < reccount; ++i){ _createRow(i);  }                     /*  tr, td, dataSource */
    $(idx+"_tbody").css({ fontSize: ops.fontSize });                        /* itt csak ez a "map"-os működött*/
    var tbody_height = ($(idx+"_tbody tr").height()*ops.maxVisibleRow) | 0; /* tbody szükséges magassága */
    $(idx+"_tbody").css('height',tbody_height);                             /* beállítja a szükséges magasságot: px*/                                
    var széles = $(idx).width() - (ops.buttons.length  * 46);               /* a lábléc szöveg szélessége TOTAL- a gombok száma*gomb szélesség */
    $(idx+"_láb").css('width',széles); 
    $(idx+"_szum").html(_szum());

    /*-------------- sor (tr,td) generálása ------------------------------*/
    function _createRow(index) {
        var key="", align="", tag0="", tag1="", sor="", t="", sumindex= -1;
        var tbody = document.getElementById(id+"_tbody");
        var row = tbody.insertRow(index);
        row.id = id+"_tr_"+index;
        
        for (var i=0; i < ops.columns.length; i++) {
            key = ops.columns[i].field;
            sumindex = ops.sum.indexOf(key);    /* van erre az oszlopra összesítési kérés? */
            if (sumindex > -1) { sumtb[sumindex] += Number(ops.dataSource[index][key]); }  /* ha kért összesítést, akkor itt van..., ha nem szám, akkor nyekk..*/
                
            align = ops.columns[i].align==="C"?"center":ops.columns[i].align==="R"?"right":"";

            if (ops.columns[i].cid === cid) {   // egyenlő az oszlopszám az előzővel: a két érték egy <td>-be kerül 
                sor = "&nbsp;"; 
                if (ops.columns[i].title.length!==0) {  // ha van title, akkor kétsoros <strong><span> szerkesztés lesz.
                    tag0="<span>"; tag1="</span>" ; sor = "";
                }  
            } else {                                          // nem egyenlő az előzővel: külön <td> 
                var szeles = "style='width:"+ops.columns[i].width+"px;'";    
                sor = "<td id="+(id+"_td_"+index+"_"+i)+" class='"+align+"' "+szeles+">";
                cid = ops.columns[i].cid; // frissít
                if (i < ops.columns.length-1 && cid===ops.columns[i+1].cid && ops.columns[i+1].title.length!==0 )  // ha nem az utolsó oszlop és a cid=a köv. cid-el és a következőnek van title értéke
                    { tag0="<strong>"; tag1="</strong>" ;   }
            }
            t += (sor + tag0+ops.columns[i].pref + ops.dataSource[index][key] + ops.columns[i].suff+tag1);
            if (i === ops.columns.length-1 || ops.columns[i].cid !== cid) {t += "</td>";} // ha ez az utolsó érték a for-ban, vagy cid nem volt egyenlő   
        }    
        row.innerHTML = t;
    }

    function _szum() {
        var összes = "";
        for (var i=0; i < ops.sum.length; i++) {                                /* összesítés kiírása */
            var x = -1;
            for (var j = 0; j < ops.columns.length; j++) {
                    if (ops.columns[j].field === ops.sum[i]){ x = j; }              /* itt van az akt. sor*/
            }
            összes += "Szum "+ops.columns[x].title+"="+ops.columns[x].pref+
            sumtb[i].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")+ ops.columns[x].suff+ " | ";    // előtag, ezres tagoló, utótag
        }
        return összes;       
    }

    /*------------------------ táblaKurzor mozgatása ---------------------*/
    $(idx+"_tbody").on("click", "tr", function( event ) {                   /* ---- TR ONCLICK ESEMÉNY ------  */
        var r = $(this).closest("tr");                                      /* akt. row , kell scroll?0:nem:igen*/
        _setCursor ( r.index(), 0 ) ;  
    });

    function _setCursor(index, scroll ) {                                   /* táblázatkurzor mozgatása */
        if (!ops.táblaCursor || index >= reccount ) {return ;}              /* nem kért táblakurzort, vagy nagyobb mint az elemszám*/
        index = Math.max(Math.min(index, reccount-1),0);                    /* no overflow */
        
        var ez = $(idx+" table tbody tr");                                 
        if (ops.tCursor > -1) { ez.eq(ops.tCursor).removeClass('active'); } /* előző - esetleges kijelölt sor deaktív */
        ez.eq(index).addClass('active');
        ops.tCursor = index;                                                /* táblakurzor frissítése */ 
        if (ops.counter) {                                                  /* ha kért számlálót */
            $(idx+"_recno").html(ops.tCursor+1);
            $(idx+"_reccount").html(reccount);   
        }             
        if (scroll===1) {                                                   /* scroll az akt. sorra */
            var w = $(idx+" table tbody");
            var body_h = w.height();                                        /* tbody magassága */
            var tr_h   = ez.height();                                       /* egy sor magassága (csak egyformák legyenek a sorok:-) */
            w.scrollTop( tr_h * (index+1) - (body_h / 2) );                 /* így pont középre kerül a kijelölt sor */
        }
    }
    
    function _jsonSetRow(i, field, value) {                                 // sor módosítása
        ops.dataSource[i][field] = value;                                   // json[i] refresh
        _setRow(i);                                                         // tábla[i] refresh
        if (i === ops.tCursor) {_setCursor(i, 0);}                          // tCursor refresh
    }
    
    function _setRow (index) {                                              /* feltölti tr index. elemét json index. elemével  */
        var  sor, spc, tag0, tag1, cid=-1;
        var row = $(idx+"_tbody tr").eq(index);                             /* akt sor meghatározása */
        var colcount = $(idx+"_tbody tr td").length;
        for (var i = 0; i < colcount; i++) { 
            sor = ""; tag0=""; tag1=""; spc = "";
            $(ops.columns).each(function (j, item) {                        /* j: poz, item: value*/
                if (i === item.cid) {                                       /* ha van ilyen (több) oszlop poz. érték */
                    if (cid === item.cid) {                                 // egyenlő az oszlopszám az előzővel: a két érték egy <td>-be kerül
                        spc = "&nbsp;";
                        if (item.title.length!==0) {                        // ha van title, akkor kétsoros <strong><span> szerkesztés lesz.
                            tag0="<span>"; tag1="</span>"; spc = ""; 
                        } 
                    } else {
                        cid = item.cid;
                        if (j < ops.columns.length-1 && cid===ops.columns[j+1].cid && ops.columns[j+1].title.length!==0 )  // ha nem az utolsó oszlop és a cid=a köv. cid-el és a következőnek van title értéke
                        { tag0="<strong>"; tag1="</strong>" ;   }
                    }
                    sor += spc+tag0+item.pref+ops.dataSource[index][item.field]+item.suff+tag1;
                }
            });
            $(row).find('td').eq(i).html(sor);
        }
    }
    
    function _getRealColumn (index) {                                       // visszaadja a valós oszlop értéket
        var rc = -1;
        for (var i = 0; i < ops.columns.length; i++) {                      // keressük az oszlop sorszámot
            if (rc < 0 && ops.columns[i]["cid"]===index) { rc = i; }        // mi az oszlop field neve (és még nincs bent érték)
        }
    return rc;}
    
    /*-------------------rendezés: th click ------------------------------*/
    $( idx+" table thead th" ).on("click", function( event ) {              /* ---- Th ONCLICK ESEMÉNY ------  */
        var x = $(this).index()+1;                                          // a 0 no order-t jelent
        orderBy = (orderBy !==x) ? x : x * -1;                              // x+1: az első oszlop: 1.
        var ez = $(idx+" table tbody tr");
        var i = _getRealColumn (x-1);
        var key  =ops.columns[i]["field"];
        var tipus=ops.columns[i]["type"];                                   // rendezés num, vagy stirng
        ez.eq(ops.tCursor).removeClass('active');                           /* előző - esetleges kijelölt sor deaktív */
        ops.tCursor= -1;                                                    // táblakurzor off
        $(idx+"_recno").html(0);
        $(idx+"_search").val("");                                           // esetleges kereső input üres
        $(idx+"_search").attr("placeholder", ops.columns[i].title);
        $(idx+" thead th .order").css({ display: "none" }); 
        $(idx+" thead th .order").eq(x-1).css({ display: "block" }); 


        ops.dataSource.sort(function (a, b) {                               // json orderBy
            var x, y;
            if (tipus==="n") {x= parseInt(a[key]); y= parseInt(b[key]);}    // eltérő típusok, eltérő rendezés
            else             {x= a[key];         y= b[key];}
            var vissza;
            if (orderBy > 0) {vissza = (x < y) ? -1 : ((x > y) ? 1 : 0);}   // asc order
            else             {vissza = (x > y) ? -1 : ((x < y) ? 1 : 0);}   // desc order
            return vissza;
        });
        for (var i = 0; i < reccount; i++) { _setRow(i); }                  // újra betölti a jsont a táblába (formátum és event marad)
    });
    
    /*  ------------  ins, del, upd, --------------------------------------*/
    function _tCursor() { return ops.tCursor; }
    function _getRowField (index, field) {                                  /* i. sor "field" mező értéke (ha van*/
        var x;
        try { x = ops.dataSource[index][field]; }                           // nem biztos, hogy létezik ...
        catch (err) { x = -1; }
        return x;
    }
        
    function _delRow(index )   {                                            /* törli az index sorszámú elemet */
        if (index < 0 || index > reccount-1) return;
        ops.dataSource.splice(index, 1);                                    /* index.elem törlése (1 hosszan) */
        --reccount;
        $(idx+"_tbody tr").eq(index).remove();                              // tr törlése
        $(idx+"_szum").html("");                                            // szum már érvénytelen, így kuka
        _setCursor( index-1, 1);                                            /* tcursor + lábléc refresh */
    }  
    
    /* ------input keydown,  buttons: scroll, ins, upd, del, inf, src ----*/

    if (ops.buttons.indexOf("home")>-1) {                                   /* ha kért home gombot: buttons[] */
        $(idx+"_home").click(function(){ 
            var rowpos = $(idx+' table tbody tr:first').position();
            $(idx+"_tbody").scrollTop(rowpos.top);  });
    }
    if (ops.buttons.indexOf("end")>-1) {
        $(idx+"_end").click(function(){ 
            var rowpos = $(idx+' table tbody tr:last').position();
            $(idx+"_tbody").scrollTop(rowpos.top);  });
    }
    
    if (ops.buttons.indexOf("src")>-1) {                                    // keresés gomb (rendezett oszlopra)
        $(idx+"_src").click(function(){ 
            if ($(idx+"_search").is(":visible")) {
                $(idx+"_search").css({ display: "none" });                  // input off
                return;
            }
            
            var x = _getRealColumn(Math.abs(orderBy)-1);                    // melyik oszlopra kattintottak (lehet negatív is)
            if (x >= 0 ) {                                                  // ha x > 0 akkor, egyébként nincs rendezés
                $(idx+"_search").val("");
                $(idx+"_search").css({ display: "block" });                  // input on
                $(idx+"_search").focus();
            }
        });
        
        $(idx+"_search").keyup(function(){                                  // akt. keresőinput leütött bill. feldolgozása
            var s = (this.value).toUpperCase();
            var x = _getRealColumn(Math.abs(orderBy)-1);                    // melyik oszlopra kattintottak (lehet negatív is)
            if (x >= 0 && s.length) {                                       // ha van rend. oszlop és van az inputban string 
                var field =ops.columns[x].field;                                  
                var poz = -1;
                for (var i=0; i < reccount; ++i) {
                    if ((ops.dataSource[i][field]).substr(0,s.length).toUpperCase()===s){ poz=i; break; }
                } 
                if (poz > -1 ) { _setCursor(poz,1); }                       // találat
            }
        });
    }
    
    if (ops.buttons.indexOf("ins") >-1) { $(idx+'_ins').click(function() { ops.ins_something();  });}
    if (ops.buttons.indexOf("upd") >-1) { $(idx+'_upd').click(function() { ops.upd_something();  });}
    if (ops.buttons.indexOf("del") >-1) { $(idx+'_del').click(function() { ops.del_something();  });}
    if (ops.buttons.indexOf("inf") >-1) { $(idx+'_inf').click(function() { ops.inf_something();  });}
    if (ops.buttons.indexOf("load")>-1) { $(idx+'_load').click(function(){ ops.load_something(); });}
        
    function _clearData() {
        var tbody = document.getElementById(id+"_tbody");
        for (var i = reccount-1; i >= 0; --i) { tbody.deleteRow(i); }       
        ops.dataSource = [];
        ops.tCursor = -1;
        reccount = 0;
        orderBy = 0; 
        sumtb = Array(ops.sum.length).fill(0);                              // sum reset
        $(idx+"_recno").html(0); 
        $(idx+"_reccount").html(0);
        $(idx+"_szum").html("");
        $(idx+" thead th .order").css({ display: "none" });
        $(idx+"_search").css({ display: "none" }); 
    }   
    
    function _addNewData(data) {
        _clearData();
        ops.dataSource = data;
        reccount = ops.dataSource.length;
        for (var i=0; i < reccount; ++i){ _createRow(i);  }
        $(idx+"_reccount").html(reccount);
        $(idx+"_szum").html(_szum());
    }
    
    };
    
})(jQuery); 